#!python

import os
import sys

benchmarks = ["462.libquantum",
              "400.perlbench" ,
              "403.gcc"       ,
              "471.omnetpp"   ,
              "429.mcf"       ,
              "473.astar"     ,
              "401.bzip2"]

for bench in benchmarks:
    
